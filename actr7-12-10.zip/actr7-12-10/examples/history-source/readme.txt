Simple example not yet available, but see the tools/trace-history.lisp
file for an example which is used by the system.