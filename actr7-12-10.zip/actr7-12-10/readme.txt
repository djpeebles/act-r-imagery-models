This system is a work in progress and not recommended for real modeling work.

The recommended version of the ACT-R software can be found on the ACT-R 
website at: <http://act-r.psy.cmu.edu>.

This new version is being developed as a way to provide an external interface
for interacting with the ACT-R software and models.  The eventual goal is to
allow access to all of the currently documented capabilities remotely (for 
example, one could connect a new module written in a language other than Lisp,
an experiment written in another different language, and run a model using
both of those from something else that isn't Lisp, like an interactive Python
session).  Currently, the focus is on providing the modeling tools and 
the current experiment building interface for remote use (the second two 
items in the example), and if that works out well the next step will be toward
more of the internal components (like module creation).

It is based on ACT-R 7 in terms of the underlying cognitive architecture and
the overall software design, and it is able to run some ACT-R 7 models as-is.
It will not run ACT-R 7 models that create a new device for the perceptual/
motor interface because that has been completely reworked for remote interaction,
and at this time, it only provides a single meta-process (clock and scheduler) 
which means it will not support running multiple models asynchronously.

Currently, the version info shows it to be ACT-R 9.  That is because the 
convention has been to number the speculative/transitional versions with odd 
numbers, and given the complaints about the version 6.1 naming I wanted to
make it something distinct for now.  However, under the version numbering
system that was given at the 2016 PGSS this "really" is 7.6 which will
probably be the official version once it's more stable.

There isn't a lot of documentation on this yet, but the QuickStart.txt file
has been updated with some very basic info if one wants to try it, and there
is a document with some very basic information on how it works in the DES.doc
file in the docs directory.  It still includes the ACT-R 7 manuals, but those 
have NOT yet been updated to reflect any of the changes that have been made to 
the system.  The models in the examples directory have also not been updated.
However, all of the tutorial models and tasks HAVE been updated and will
run as they did before, but they are now split into multiple files: one file 
contains the ACT-R model definition and the other contains the code to perform the
experiment, collect the data, and report the results.  There are currently two
versions of each of the 'experiment' files (one written in Lisp and one written
in Python), and either of them will work using the same underlying model file.
But, not all of the tutorial texts have been updated yet to provide appropriate 
instructions for using the new versions of the tasks.

