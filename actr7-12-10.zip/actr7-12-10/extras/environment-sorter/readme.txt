Call (require-extra "environment-sorter") or move this file into the other-files
directory of the ACT-R 7 distribution before loading ACT-R 7 if you would like 
all of the list boxes displayed in the environment dialogs to be sorted 
alphabetically instead of the default ordering (which for some dialogs is arbitrary).
